package DPP_Order;
        
public abstract class FoodDecorator extends Food {
	protected Food food;
    public abstract String getFoodName();
    
}
