package DPP_Order;

public class Tteokbokki extends Food{

    public Tteokbokki() {
        super();
        Foodname="떡볶이";
    }

    @Override
    public int cost() {
        return 4000;
    }
    
}
