package DPP_Seat;

public class Seat_Single {
    // 외부에 제공할 자기 자신의 인스턴스
    private static Seat_Single seat_single = null;
    
    private int power = 0;    // 전원
    private int num = 0;      //좌석 번호
    private Seat_Single(){}   // Seat_Single 생성자를 외부에서 사용 불가

    public int getPower() {
        return power;
    }
    
    public void setPower(int power) {
        this.power = power;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
    
    public static Seat_Single getInstance(){    //자기 자신의 인스턴스를 외부에 제공
        if(seat_single == null){  
            // Seat_Single 인스턴스 생성
            seat_single = new Seat_Single();
        }
        return seat_single;
    }
}
