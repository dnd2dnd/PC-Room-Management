package DPP_Seat;

import DPP_Login.Login;

public class Seat extends javax.swing.JFrame {

    public Seat() {
        initComponents();
        setLocationRelativeTo(null);    // 화면 가운데서 창이 나옴
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SEAT1 = new javax.swing.JButton();
        SEAT2 = new javax.swing.JButton();
        SEAT3 = new javax.swing.JButton();
        SEAT4 = new javax.swing.JButton();
        SEAT5 = new javax.swing.JButton();
        SEAT6 = new javax.swing.JButton();
        SEAT7 = new javax.swing.JButton();
        SEAT8 = new javax.swing.JButton();
        SEAT9 = new javax.swing.JButton();
        SEAT10 = new javax.swing.JButton();
        SEAT12 = new javax.swing.JButton();
        SEAT11 = new javax.swing.JButton();
        SEAT13 = new javax.swing.JButton();
        SEAT14 = new javax.swing.JButton();
        SEAT15 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        SEAT1.setText("1번 자리");
        SEAT1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT1ActionPerformed(evt);
            }
        });

        SEAT2.setText("2번 자리");
        SEAT2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT2ActionPerformed(evt);
            }
        });

        SEAT3.setText("3번 자리");
        SEAT3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT3ActionPerformed(evt);
            }
        });

        SEAT4.setText("4번 자리");
        SEAT4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT4ActionPerformed(evt);
            }
        });

        SEAT5.setText("5번 자리");
        SEAT5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT5ActionPerformed(evt);
            }
        });

        SEAT6.setText("6번 자리");
        SEAT6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT6ActionPerformed(evt);
            }
        });

        SEAT7.setText("7번 자리");
        SEAT7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT7ActionPerformed(evt);
            }
        });

        SEAT8.setText("8번 자리");
        SEAT8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT8ActionPerformed(evt);
            }
        });

        SEAT9.setText("9번 자리");
        SEAT9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT9ActionPerformed(evt);
            }
        });

        SEAT10.setText("10번 자리");
        SEAT10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT10ActionPerformed(evt);
            }
        });

        SEAT12.setText("12번 자리");
        SEAT12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT12ActionPerformed(evt);
            }
        });

        SEAT11.setText("11번 자리");
        SEAT11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT11ActionPerformed(evt);
            }
        });

        SEAT13.setText("13번 자리");
        SEAT13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT13ActionPerformed(evt);
            }
        });

        SEAT14.setText("14번 자리");
        SEAT14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT14ActionPerformed(evt);
            }
        });

        SEAT15.setText("15번 자리");
        SEAT15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SEAT15ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SEAT5)
                    .addComponent(SEAT4)
                    .addComponent(SEAT3)
                    .addComponent(SEAT2)
                    .addComponent(SEAT1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SEAT10)
                    .addComponent(SEAT9)
                    .addComponent(SEAT8)
                    .addComponent(SEAT7)
                    .addComponent(SEAT6))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(SEAT15)
                    .addComponent(SEAT14)
                    .addComponent(SEAT13)
                    .addComponent(SEAT12)
                    .addComponent(SEAT11))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(SEAT11)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT12)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT13)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT14)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT15))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(SEAT6)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT7)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT8)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT9)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT10))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(SEAT1)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT2)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT3)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT4)
                        .addGap(18, 18, 18)
                        .addComponent(SEAT5)))
                .addContainerGap(58, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SEAT1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT1ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(1);     //자리 1번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT1ActionPerformed

    private void SEAT2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT2ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(2);     //자리 2번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT2ActionPerformed

    private void SEAT3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT3ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(3);     //자리 3번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT3ActionPerformed

    private void SEAT4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT4ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(4);     //자리 4번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT4ActionPerformed

    private void SEAT5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT5ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(5);     //자리 5번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT5ActionPerformed

    private void SEAT6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT6ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(6);     //자리 6번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT6ActionPerformed

    private void SEAT7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT7ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(7);     //자리 7번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT7ActionPerformed

    private void SEAT8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT8ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(8);     //자리 8번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT8ActionPerformed

    private void SEAT9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT9ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(9);     //자리 9번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT9ActionPerformed

    private void SEAT10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT10ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(10);    //자리 10번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT10ActionPerformed

    private void SEAT11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT11ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(11);    //자리 11번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT11ActionPerformed

    private void SEAT12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT12ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(12);    //자리 12번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT12ActionPerformed

    private void SEAT13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT13ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(13);    //자리 13번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT13ActionPerformed

    private void SEAT14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT14ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(14);    //자리 14번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT14ActionPerformed

    private void SEAT15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SEAT15ActionPerformed
        Seat_Single seat = Seat_Single.getInstance();   // 싱글톤 객체 생성
        seat.setPower(1);   //전원 켜짐
        seat.setNum(15);    //자리 15번
        Login next = new Login();
        next.setVisible(true);
        dispose();
    }//GEN-LAST:event_SEAT15ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Seat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Seat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Seat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Seat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Seat().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SEAT1;
    private javax.swing.JButton SEAT10;
    private javax.swing.JButton SEAT11;
    private javax.swing.JButton SEAT12;
    private javax.swing.JButton SEAT13;
    private javax.swing.JButton SEAT14;
    private javax.swing.JButton SEAT15;
    private javax.swing.JButton SEAT2;
    private javax.swing.JButton SEAT3;
    private javax.swing.JButton SEAT4;
    private javax.swing.JButton SEAT5;
    private javax.swing.JButton SEAT6;
    private javax.swing.JButton SEAT7;
    private javax.swing.JButton SEAT8;
    private javax.swing.JButton SEAT9;
    // End of variables declaration//GEN-END:variables
}
