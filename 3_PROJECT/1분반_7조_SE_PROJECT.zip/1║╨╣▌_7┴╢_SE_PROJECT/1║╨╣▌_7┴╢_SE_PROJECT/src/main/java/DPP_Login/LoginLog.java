package DPP_Login;

public class LoginLog {
    private static String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    } 
}
