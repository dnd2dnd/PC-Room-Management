package DPP_Time;

public class StateNotice implements Observer {
    private int Chour=0;        //현재 시
    private int Cminutes=0;     //현재 분
    private int Csecond=0;      //현재 초
    private TimeData timeData;

    public StateNotice(TimeData timeData) {
        this.timeData = timeData;
        timeData.registerObserver(this);
    }

    @Override
    public void update(int hour, int minutes, int second) {
        Chour=hour;
        Cminutes=minutes;
        Csecond=second;    
        display();
    }

    public void display() {   // 상태 변화
        if(Chour<=0&&Cminutes<=0&&Csecond<=0){
            System.out.println("충전해주세요~");
        }else if(Chour==0&&Cminutes==3&&Csecond==0){
            System.out.println("3분 남았습니다.");
        }else if(Chour==0&&Cminutes==5&&Csecond==0){
            System.out.println("5분 남았습니다.");
        }
        System.out.println("");
    }
}