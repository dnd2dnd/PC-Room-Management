package DPP_Time;

public class CurrentTimeNotice implements Observer {
    private int hour;
    private int minutes;
    private int second;
    private TimeData timeData;
            
    public CurrentTimeNotice(TimeData timeData) {
        this.timeData = timeData;
        timeData.registerObserver(this);
    }
    
    @Override
    public void update(int hour, int minutes, int second) {
        this.hour=hour;
        this.minutes=minutes;
        this.second=second;
        display();
    }
    public void display() {
        System.out.println(hour+"시간 "+minutes+"분 "+second+ "초");
    }
}
