package DPP_Time;

public interface Observer {
	public void update(int hour, int minutes, int second);
}